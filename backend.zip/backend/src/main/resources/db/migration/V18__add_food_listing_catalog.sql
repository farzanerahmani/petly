-- Petly V18: canonical package variants, shop listings, scrape checks and match review.
-- This migration changes schema only; it does not seed, delete or rewrite business data.

-- 1) Canonical package variants. A product may have one unknown-weight variant.
CREATE TABLE food_variants (
    id BIGSERIAL PRIMARY KEY,
    food_product_id BIGINT NOT NULL
        REFERENCES food_products (id) ON DELETE CASCADE,
    package_weight_grams INTEGER,
    weight_status VARCHAR(20) NOT NULL
        CHECK (weight_status IN ('CONFIRMED', 'NEEDS_REVIEW', 'MULTIPLE_WEIGHTS', 'WEIGHT_UNKNOWN')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_food_variants_weight
        CHECK (package_weight_grams IS NULL OR package_weight_grams > 0),
    CONSTRAINT chk_food_variants_weight_status
        CHECK (
            (package_weight_grams IS NULL AND weight_status IN ('MULTIPLE_WEIGHTS', 'WEIGHT_UNKNOWN', 'NEEDS_REVIEW'))
            OR
            (package_weight_grams IS NOT NULL AND weight_status IN ('CONFIRMED', 'NEEDS_REVIEW'))
        )
);

CREATE UNIQUE INDEX uq_food_variants_product_weight
    ON food_variants (food_product_id, package_weight_grams)
    WHERE package_weight_grams IS NOT NULL;

CREATE UNIQUE INDEX uq_food_variants_product_unknown_weight
    ON food_variants (food_product_id)
    WHERE package_weight_grams IS NULL;

CREATE INDEX idx_food_variants_product
    ON food_variants (food_product_id);

-- 2) One source-shop listing is independent from the canonical product match.
-- food_variant_id is set only after a human-approved match.
CREATE TABLE food_listings (
    id BIGSERIAL PRIMARY KEY,
    pet_shop_id BIGINT NOT NULL
        REFERENCES pet_shops (id) ON DELETE RESTRICT,
    food_variant_id BIGINT
        REFERENCES food_variants (id) ON DELETE SET NULL,
    external_product_id VARCHAR(200),
    raw_product_name VARCHAR(500) NOT NULL,
    product_url TEXT NOT NULL,
    matching_status VARCHAR(24) NOT NULL DEFAULT 'UNMATCHED'
        CHECK (matching_status IN ('UNMATCHED', 'NEEDS_REVIEW', 'MANUAL_CONFIRMED')),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_food_listings_confirmed_match
        CHECK ((matching_status = 'MANUAL_CONFIRMED' AND food_variant_id IS NOT NULL)
            OR matching_status <> 'MANUAL_CONFIRMED'),
    CONSTRAINT uq_food_listings_shop_url UNIQUE (pet_shop_id, product_url)
);

CREATE INDEX idx_food_listings_shop_active
    ON food_listings (pet_shop_id, is_active);
CREATE INDEX idx_food_listings_variant
    ON food_listings (food_variant_id);
CREATE INDEX idx_food_listings_matching_status
    ON food_listings (matching_status);

-- 3) Every scraper observation is retained, including unknown availability.
CREATE TABLE food_listing_checks (
    id BIGSERIAL PRIMARY KEY,
    food_listing_id BIGINT NOT NULL
        REFERENCES food_listings (id) ON DELETE CASCADE,
    availability VARCHAR(20) NOT NULL DEFAULT 'UNKNOWN'
        CHECK (availability IN ('IN_STOCK', 'OUT_OF_STOCK', 'UNKNOWN')),
    stock_text VARCHAR(500),
    scrape_error TEXT,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_food_listing_checks_listing_checked
    ON food_listing_checks (food_listing_id, checked_at DESC);

-- 4) Allow price observations to exist before a canonical product is matched.
-- A missing price and/or currency means unknown price; zero is never used as a sentinel.
ALTER TABLE food_prices
    ALTER COLUMN food_product_id DROP NOT NULL,
    ALTER COLUMN price_amount DROP NOT NULL,
    ALTER COLUMN currency DROP NOT NULL;

ALTER TABLE food_prices
    DROP CONSTRAINT food_prices_food_product_id_fkey;

ALTER TABLE food_prices
    ADD CONSTRAINT food_prices_food_product_id_fkey
        FOREIGN KEY (food_product_id)
        REFERENCES food_products (id) ON DELETE SET NULL;

ALTER TABLE food_prices
    ADD COLUMN food_listing_id BIGINT,
    ADD COLUMN listing_check_id BIGINT;

ALTER TABLE food_prices
    ADD CONSTRAINT fk_food_prices_listing
        FOREIGN KEY (food_listing_id)
        REFERENCES food_listings (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_food_prices_listing_check
        FOREIGN KEY (listing_check_id)
        REFERENCES food_listing_checks (id) ON DELETE SET NULL,
    ADD CONSTRAINT chk_food_prices_product_or_listing
        CHECK (food_product_id IS NOT NULL OR food_listing_id IS NOT NULL),
    ADD CONSTRAINT chk_food_prices_amount_currency_pair
        CHECK (
            (price_amount IS NULL AND currency IS NULL)
            OR
            (price_amount IS NOT NULL AND price_amount > 0 AND currency IS NOT NULL AND currency IN ('IRR', 'IRT'))
        );

CREATE INDEX idx_food_prices_listing_checked
    ON food_prices (food_listing_id, checked_at DESC);
CREATE INDEX idx_food_prices_listing_check
    ON food_prices (listing_check_id);

-- A scraper check may have at most one corresponding price observation.
CREATE UNIQUE INDEX uq_food_prices_listing_check
    ON food_prices (listing_check_id)
    WHERE listing_check_id IS NOT NULL;

-- 5) Candidate matches are suggestions only; they do not link the listing.
CREATE TABLE food_match_candidates (
    id BIGSERIAL PRIMARY KEY,
    food_listing_id BIGINT NOT NULL
        REFERENCES food_listings (id) ON DELETE CASCADE,
    food_variant_id BIGINT NOT NULL
        REFERENCES food_variants (id) ON DELETE CASCADE,
    confidence_score NUMERIC(5, 2)
        CHECK (confidence_score IS NULL OR confidence_score BETWEEN 0 AND 100),
    match_reason TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'NEEDS_REVIEW'
        CHECK (status IN ('NEEDS_REVIEW', 'APPROVED', 'REJECTED')),
    reviewed_at TIMESTAMPTZ,
    review_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_food_match_candidate UNIQUE (food_listing_id, food_variant_id)
);

CREATE INDEX idx_food_match_candidates_status
    ON food_match_candidates (status, created_at DESC);
