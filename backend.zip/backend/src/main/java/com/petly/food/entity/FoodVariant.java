package com.petly.food.entity;

import com.petly.common.entity.BaseEntity;
import com.petly.food.entity.enums.WeightStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author farzane.rahmani
 * @created 11/3/2026
 */
@Entity
@Table(
        name = "food_variants",
        indexes = {
                @Index(
                        name = "idx_food_variants_product",
                        columnList = "food_product_id"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
public class FoodVariant extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "food_product_id", nullable = false)
    private FoodProduct foodProduct;

    /*
     * Null means the package weight is currently unknown.
     */
    @Column(name = "package_weight_grams")
    private Integer packageWeightGrams;

    @Column(name = "weight_status", nullable = false, length = 30)
    @Enumerated(EnumType.STRING)
    private WeightStatus weightStatus;

    @OneToMany(mappedBy = "foodVariant")
    private List<FoodListing> listings = new ArrayList<>();

    @OneToMany(mappedBy = "foodVariant")
    private List<FoodMatchCandidate> matchCandidates = new ArrayList<>();
}

