package com.petly.common.controller;

import com.petly.common.exception.ApiError;
import com.petly.common.response.ApiResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author farzane.rahmani
 * @created 9/25/2026
 */
@RestController
@RequestMapping("/api/v1")
public class HealthController {

    @GetMapping("/health")
    public ApiResponse<Map<String, String>> healthCheck() {

        return ApiResponse.success(Map.of("status", "UP"));
    }
}
