package com.petly.pet.service;

import com.petly.auth.service.CurrentUserService;
import com.petly.pet.controller.dto.CreatePetRequestDto;
import com.petly.pet.controller.dto.PetResponseDto;
import com.petly.pet.controller.dto.UpdatePetRequestDto;
import com.petly.pet.entity.Pet;
import com.petly.pet.entity.PetMembership;
import com.petly.pet.entity.enums.CurrentFoodSatisfaction;
import com.petly.pet.entity.enums.FoodTypePreference;
import com.petly.pet.entity.enums.PetMembershipRole;
import com.petly.pet.repository.PetMembershipRepository;
import com.petly.pet.repository.PetRepository;
import com.petly.pet.service.conventor.PetConverter;
import com.petly.user.entity.User;
import com.petly.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author farzane.rahmani
 * @created 9/27/2026
 */
@Service
@RequiredArgsConstructor
public class PetService {

    private final PetRepository petRepository;
    private final UserRepository userRepository;
    private final PetMembershipRepository petMembershipRepository;
    private final PetConverter petConverter;

    private final CurrentUserService currentUserService;


    public PetResponseDto getPetById(Long petId) {
        ensurePetBelongsToCurrentUser(petId);

        var pet = petRepository.findById(petId)
                .orElseThrow(() -> new IllegalArgumentException("pet not found"));

        return petConverter.convertToPetResponseDto(pet);
    }

    @Transactional
    public PetResponseDto createPet(CreatePetRequestDto requestDto) {

        Long userId = currentUserService.getCurrentUserId();

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("user not found"));

        Pet pet = new Pet();
        pet.setName(requestDto.getName());
        pet.setSpecies(requestDto.getSpecies());
        pet.setGender(requestDto.getGender());
        pet.setBreed(requestDto.getBreed());
        pet.setActivityLevel(requestDto.getActivityLevel());
        pet.setBirthDate(requestDto.getBirthDate());
        pet.setNeutered(requestDto.getNeutered());
        pet.setFoodTypePreference(
                requestDto.getFoodTypePreference() != null
                        ? requestDto.getFoodTypePreference()
                        : FoodTypePreference.NO_PREFERENCE
        );

        pet.setCurrentFood(
                requestDto.getCurrentFood() == null
                        ? null
                        : requestDto.getCurrentFood().trim()
        );

        pet.setCurrentFoodSatisfaction(
                requestDto.getCurrentFoodSatisfaction() != null
                        ? requestDto.getCurrentFoodSatisfaction()
                        : CurrentFoodSatisfaction.UNKNOWN
        );

        Pet savedPet = petRepository.save(pet);
        PetMembership membership = new PetMembership();
        membership.setUser(user);
        membership.setPet(savedPet);
        membership.setRole(PetMembershipRole.PRIMARY_OWNER);
        petMembershipRepository.save(membership);

        return petConverter.convertToPetResponseDto(savedPet);
    }

    @Transactional
    public void updatePet(Long petId, UpdatePetRequestDto requestDto) {

        ensurePetBelongsToCurrentUser(petId);
        var pet = petRepository.findById(petId)
                .orElseThrow(() -> new IllegalArgumentException("pet not found"));

        pet.setGender(requestDto.getGender());
        pet.setName(requestDto.getName());
        pet.setActivityLevel(requestDto.getActivityLevel());
        pet.setBreed(requestDto.getBreed());
        pet.setBirthDate(requestDto.getBirthDate());
        petRepository.save(pet);
    }

    @Transactional
    public List<PetResponseDto> getAllPets() {
        Long userId = currentUserService.getCurrentUserId();

        var memberships = petMembershipRepository.findAllByUserId(userId);

        var pets = memberships.stream()
                .map(PetMembership::getPet)
                .toList();

        return petConverter.convertToListPetResponseDto(pets);
    }

    private void ensurePetBelongsToCurrentUser(Long petId) {
        Long userId = currentUserService.getCurrentUserId();

        boolean hasAccess =
                petMembershipRepository.existsByUserIdAndPetId(userId, petId);

        if (!hasAccess) {
            throw new org.springframework.security.access.AccessDeniedException(
                    "You do not have access to this pet"
            );
        }
    }
}
